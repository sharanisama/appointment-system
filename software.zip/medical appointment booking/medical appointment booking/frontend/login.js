// --- START OF FILE login.js ---

document.addEventListener('DOMContentLoaded', () => {
    const loginForm = document.getElementById('loginForm');
    const errorMessageDiv = document.getElementById('loginErrorMessage');
    const emailInput = document.getElementById('email');
    const passwordInput = document.getElementById('password');

    const API_BASE_URL = 'http://localhost:3000/api'; // Adjust if needed

    loginForm.addEventListener('submit', async function (e) {
        e.preventDefault(); // Prevent default form submission
        errorMessageDiv.innerText = ''; // Clear previous errors

        const email = emailInput.value.trim();
        const password = passwordInput.value.trim();

        if (!email || !password) {
            errorMessageDiv.innerText = 'Please enter both email and password.';
            return;
        }

        try {
            const response = await fetch(`${API_BASE_URL}/login`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({ email, password }) // Keys must match backend expectation
            });

            const data = await response.json(); // Parse JSON response body

            if (response.ok) { // Check if status code is 2xx
                // alert(data.message || 'Login successful!'); // Use message from backend or default
                // --- Store user info and token ---
                if (data.user.id) {
                    localStorage.setItem('userId', data.user.id);
                    console.log(`Stored userId: ${data.user.id}`);
                } else {
                    console.warn('userId not found in login response.');
                    // Consider if login should fail if userId is missing
                }

                if (data.token) { // Assuming your backend sends a 'token' field
                    localStorage.setItem('authToken', data.token);
                    console.log('Stored authToken.');
                } else {
                     console.warn('authToken not found in login response.');
                }

                // --- Redirect to the main appointments page ---
                window.location.href = 'appointments.html'; // Redirect after successful login

            } else {
                // Show error message from backend response
                errorMessageDiv.innerText = data.message || `Login failed (Status: ${response.status})`;
            }
        } catch (error) {
            console.error('Login Fetch Error:', error);
            errorMessageDiv.innerText = 'An error occurred connecting to the server. Please try again later.';
        }
    });
});
// --- END OF FILE login.js ---