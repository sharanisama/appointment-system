
document.addEventListener('DOMContentLoaded', () => {
    const appointmentListDiv = document.getElementById('appointmentList');
    const loadingMessage = document.getElementById('loadingMessage');
    const noAppointmentsMessage = document.getElementById('noAppointmentsMessage');
    const errorMessageDiv = document.getElementById('errorMessage');

    const editFormContainer = document.getElementById('editFormContainer');
    const editForm = document.getElementById('editForm');
    const cancelEditBtn = document.getElementById('cancelEditBtn');
    const editAppointmentIdInput = document.getElementById('editAppointmentId');

    const API_BASE_URL = 'http://localhost:3000/api'; 

    function clearMessages() {
        errorMessageDiv.textContent = '';
        loadingMessage.style.display = 'none';
        noAppointmentsMessage.style.display = 'none';
    }

    function displayError(message) {
        clearMessages();
        errorMessageDiv.textContent = `Error: ${message}`;
        console.error('Error:', message);
    }

    function formatDateTimeForInput(dateString) {
        if (!dateString) return '';
        try {
            const date = new Date(dateString);
             const timezoneOffset = date.getTimezoneOffset() * 60000; 
             const localISOTime = new Date(date - timezoneOffset).toISOString().slice(0, 16);
             return localISOTime;
        } catch (e) {
            console.error("Error formatting date:", dateString, e);
            return ''; 
        }
    }

    function formatDateTimeForDisplay(dateString) {
        if (!dateString) return 'N/A';
        try {
            const date = new Date(dateString);
            return date.toLocaleString(); 
        } catch (e) {
            console.error("Error formatting display date:", dateString, e);
            return dateString; 
        }
    }


    async function fetchAppointments() {
        clearMessages();
        loadingMessage.style.display = 'block';
        appointmentListDiv.innerHTML = ''; 
        appointmentListDiv.appendChild(loadingMessage); 

        const userId = localStorage.getItem('userId'); // Example

        if (!userId) {
            displayError("User not logged in. Please log in to view appointments.");
            // window.location.href = 'login.html';
            return;
        }

        try {
            const response = await fetch(`${API_BASE_URL}/appointments/${userId}`); 

            if (!response.ok) {
                const errorData = await response.json();
                throw new Error(errorData.message || `HTTP error! Status: ${response.status}`);
            }

            const appointments = await response.json();
            clearMessages();
            displayAppointments(appointments);

        } catch (error) {
            displayError(error.message || 'Could not fetch appointments.');
        }
    }

    function displayAppointments(appointments) {
        appointmentListDiv.innerHTML = ''; 

        if (!appointments || appointments.length === 0) {
            noAppointmentsMessage.style.display = 'block';
            appointmentListDiv.appendChild(noAppointmentsMessage);
            return;
        }

        const table = document.createElement('table');
        table.innerHTML = `
            <thead>
                <tr>
                    <th>Doctor</th>
                    <th>Date & Time</th>
                    <th>Patient Name</th>
                    <th>Age</th>
                    <th>Gender</th>
                    <th>Phone</th>
                    <th>Description</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <!-- Appointment rows will be inserted here -->
            </tbody>
        `;

        const tbody = table.querySelector('tbody');

        appointments.forEach(appt => {
            const row = tbody.insertRow();
            row.setAttribute('data-id', appt.id); 
            row.innerHTML = `
                <td>${appt.doctorName || 'N/A'}</td>
                <td>${formatDateTimeForDisplay(appt.appointmentDate)}</td>
                <td>${appt.patientName || 'N/A'}</td>
                <td>${appt.patientAge || 'N/A'}</td>
                <td>${appt.patientGender || 'N/A'}</td>
                <td>${appt.patientPhone || 'N/A'}</td>
                <td>${appt.description || ''}</td>
                <td class="actions">
                    <button class="edit-btn" data-id="${appt.id}">Edit</button>
                    <button class="delete-btn" data-id="${appt.id}">Delete</button>
                </td>
            `;
        });

        appointmentListDiv.appendChild(table);

        
        table.addEventListener('click', handleTableClick);
    }

    async function handleTableClick(event) {
         const target = event.target;
         const appointmentId = target.dataset.id; 

        if (target.classList.contains('edit-btn') && appointmentId) {
            await populateEditForm(appointmentId);
        } else if (target.classList.contains('delete-btn') && appointmentId) {
            await deleteAppointment(appointmentId);
        }
    }

    async function populateEditForm(appointmentId) {
        errorMessageDiv.textContent = ''; 
        try {
            const response = await fetch(`${API_BASE_URL}/appointments/details/${appointmentId}`);
             if (!response.ok) {
                const errorData = await response.json();
                throw new Error(errorData.message || `HTTP error! Status: ${response.status}`);
            }
            const appt = await response.json();

            
            editAppointmentIdInput.value = appt.id;
            document.getElementById('editDoctorName').value = appt.doctorName || '';
            
            document.getElementById('editAppointmentDate').value = formatDateTimeForInput(appt.appointmentDate);
            document.getElementById('editPatientName').value = appt.patientName || '';
            document.getElementById('editPatientAge').value = appt.patientAge || '';
            document.getElementById('editPatientGender').value = appt.patientGender || '';
            document.getElementById('editPatientPhone').value = appt.patientPhone || '';
            document.getElementById('editDescription').value = appt.description || '';

            
            editFormContainer.style.display = 'block';
            editForm.scrollIntoView({ behavior: 'smooth' }); 

        } catch (error) {
            displayError(`Could not load appointment details: ${error.message}`);
        }
    }

     async function handleEditFormSubmit(event) {
        event.preventDefault(); 
        errorMessageDiv.textContent = ''; 

        const appointmentId = editAppointmentIdInput.value;
        const updatedData = {
            doctorName: document.getElementById('editDoctorName').value,
            appointmentDate: document.getElementById('editAppointmentDate').value, 
            patientName: document.getElementById('editPatientName').value,
            patientAge: document.getElementById('editPatientAge').value,
            patientGender: document.getElementById('editPatientGender').value,
            patientPhone: document.getElementById('editPatientPhone').value,
            description: document.getElementById('editDescription').value
        };

        try {
            const response = await fetch(`${API_BASE_URL}/appointments/${appointmentId}`, {
                method: 'PUT',
                headers: {
                    'Content-Type': 'application/json',
                    // Add authorization header if needed:
                    // 'Authorization': `Bearer ${localStorage.getItem('token')}`
                },
                body: JSON.stringify(updatedData)
            });

            if (!response.ok) {
                 const errorData = await response.json();
                
                 document.getElementById('errorMessage').textContent = `Update Failed: ${errorData.message || response.statusText}`;
                 throw new Error(errorData.message || `HTTP error! Status: ${response.status}`);
            }

            const result = await response.json();
            alert(result.message || "Appointment updated successfully!"); 

        
            editFormContainer.style.display = 'none';
            editForm.reset(); 
            await fetchAppointments(); 

        } catch (error) {
             console.error("Update failed:", error);

             
        }
    }

     async function deleteAppointment(appointmentId) {
        if (!confirm('Are you sure you want to delete this appointment?')) {
            return; 
        }

        errorMessageDiv.textContent = ''; 

        try {
            const response = await fetch(`${API_BASE_URL}/appointments/${appointmentId}`, {
                method: 'DELETE',
                headers: {
                     // Add authorization header if needed:
                    // 'Authorization': `Bearer ${localStorage.getItem('token')}`
                }
            });

            if (!response.ok) {
                const errorData = await response.json();
                throw new Error(errorData.message || `HTTP error! Status: ${response.status}`);
            }

            const result = await response.json();
             alert(result.message || "Appointment deleted successfully!");

            const rowToRemove = appointmentListDiv.querySelector(`tr[data-id="${appointmentId}"]`);
            if (rowToRemove) {
                rowToRemove.remove();
                const tbody = appointmentListDiv.querySelector('tbody');
                 if (tbody && tbody.rows.length === 0) {
                     fetchAppointments(); 
                 }
            } else {
                 await fetchAppointments();
            }

        } catch (error) {
            displayError(`Could not delete appointment: ${error.message}`);
        }
    }

    editForm.addEventListener('submit', handleEditFormSubmit);
    cancelEditBtn.addEventListener('click', () => {
        editFormContainer.style.display = 'none';
        editForm.reset();
        errorMessageDiv.textContent = ''; 
    });


    fetchAppointments(); 

});
