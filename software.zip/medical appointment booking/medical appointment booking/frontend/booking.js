// --- START OF FILE booking.js ---

document.addEventListener('DOMContentLoaded', () => {
    const appointmentForm = document.getElementById('appointmentForm');
    const messageArea = document.getElementById('messageArea');

    const API_BASE_URL = 'http://localhost:3000/api'; // Adjust if needed

    appointmentForm.addEventListener('submit', async (e) => {
        e.preventDefault();
        messageArea.textContent = ''; // Clear previous messages
        messageArea.className = ''; // Clear previous classes (success/error)

        // --- Get userId from localStorage ---
        const userId = localStorage.getItem('userId');

        if (!userId) {
            messageArea.textContent = 'Error: You must be logged in to book an appointment.';
            messageArea.className = 'error';
            // Optional: Redirect to login page after a delay
            // setTimeout(() => { window.location.href = 'login.html'; }, 3000);
            return;
        }

        // Get form values
        const doctorName = document.getElementById('doctorName').value;
        const appointmentDate = document.getElementById('appointmentDate').value;
        const description = document.getElementById('description').value;
        const patientName = document.getElementById('patientName').value;
        const patientAge = document.getElementById('patientAge').value;
        const patientGender = document.getElementById('patientGender').value;
        const patientPhone = document.getElementById('patientPhone').value;

        const appointmentData = {
            userId, // Include the retrieved userId
            doctorName,
            appointmentDate,
            description,
            patientName,
            patientAge,
            patientGender,
            patientPhone
        };

        try {
            // Add Authorization header if using token auth on backend
             const token = localStorage.getItem('authToken');
             const headers = {
                 'Content-Type': 'application/json',
             };
             if (token) {
                 headers['Authorization'] = `Bearer ${token}`;
             }


            const response = await fetch(`${API_BASE_URL}/book`, {
                method: 'POST',
                headers: headers, // Use headers potentially including Auth token
                body: JSON.stringify(appointmentData)
            });

            const data = await response.json(); // Expect JSON response

            if (response.ok) { // Status 200 or 201 typically
                messageArea.textContent = data.message || "Appointment booked successfully!";
                messageArea.className = 'success';
                appointmentForm.reset(); // Clear the form on success
            } else {
                messageArea.textContent = `Error: ${data.message || `Failed to book appointment (Status: ${response.status})`}`;
                messageArea.className = 'error';
            }
        } catch (error) {
            console.error("Booking Fetch Error:", error);
            messageArea.textContent = "An error occurred while connecting to the server. Please try again.";
            messageArea.className = 'error';
        }
    });
});
// --- END OF FILE booking.js ---