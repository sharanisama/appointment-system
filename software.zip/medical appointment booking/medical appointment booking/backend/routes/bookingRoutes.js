const express = require('express');
const router = express.Router();

// Assuming userController exists and is correctly implemented
const { registerUser, loginUser } = require('../controllers/userController');
const {
    bookAppointment,
    getAppointments,
    getAppointmentById, // <-- NEW
    updateAppointment,  // <-- NEW
    deleteAppointment   // <-- NEW
} = require('../controllers/bookingController');

console.log({
    registerUserType: typeof registerUser,
    loginUserType: typeof loginUser,
    bookAppointmentType: typeof bookAppointment,
    getAppointmentsType: typeof getAppointments
});

// User Routes
router.post('/register', registerUser);
router.post('/login', loginUser);

// Appointment Routes
router.post('/book', bookAppointment);
router.get('/appointments/:userId', getAppointments);

router.get('/appointments/details/:appointmentId', getAppointmentById);
router.put('/appointments/:appointmentId', updateAppointment);
router.delete('/appointments/:appointmentId', deleteAppointment);
module.exports = router;
