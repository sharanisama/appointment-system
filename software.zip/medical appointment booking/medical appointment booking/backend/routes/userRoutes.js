const express = require('express');
const router = express.Router();
const { registerUser, loginUser } = require('../controllers/userController');

// User Routes
router.post('/register', registerUser);  // Register user route
router.post('/login', loginUser);  // Login user route

module.exports = router;
