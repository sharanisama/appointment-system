
const db = require('../db');

exports.bookAppointment = async (req, res) => {
    const {
        userId,
        doctorName,
        appointmentDate,
        description,
        patientName,
        patientAge,
        patientGender,
        patientPhone
    } = req.body;

    if (!userId || !doctorName || !appointmentDate || !patientName || !patientAge || !patientGender || !patientPhone) {
        return res.status(400).json({ message: "Missing required appointment fields." });
    }

    try {
        const formattedDate = new Date(appointmentDate).toISOString().slice(0, 19).replace('T', ' ');

        const [result] = await db.query(
            "INSERT INTO Appointments (userId, doctorName, appointmentDate, description, patientName, patientAge, patientGender, patientPhone) VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
            [userId, doctorName, formattedDate, description || null, patientName, patientAge, patientGender, patientPhone] // Use null for optional description
        );
        res.status(201).json({ message: "Appointment booked successfully.", appointmentId: result.insertId }); // Return 201 Created, maybe send back the ID
    } catch (error) {
        console.error("Booking Error:", error);
        res.status(500).json({ message: "Failed to book appointment due to a server error." });
    }
};

exports.getAppointments = async (req, res) => {
    const userId = req.params.userId;

    if (!userId) {
        return res.status(400).json({ message: "User ID is required." });
    }

    try {
        const [appointments] = await db.query(
            "SELECT id, userId, doctorName, appointmentDate, description, patientName, patientAge, patientGender, patientPhone FROM Appointments WHERE userId = ? ORDER BY appointmentDate DESC", // Order by date
            [userId]
        );
        res.status(200).json(appointments);
    } catch (error) {
        console.error("Fetch Error:", error);
        res.status(500).json({ message: "Failed to fetch appointments due to a server error." });
    }
};


exports.getAppointmentById = async (req, res) => {
    const { appointmentId } = req.params;

    if (!appointmentId) {
        return res.status(400).json({ message: "Appointment ID is required." });
    }

    try {
        const [appointments] = await db.query(
            "SELECT id, userId, doctorName, appointmentDate, description, patientName, patientAge, patientGender, patientPhone FROM Appointments WHERE id = ?",
            [appointmentId]
        );

        if (appointments.length === 0) {
            return res.status(404).json({ message: "Appointment not found." });
        }
       
        res.status(200).json(appointments[0]); // Return the single appointment object
    } catch (error) {
        console.error("Fetch Single Appointment Error:", error);
        res.status(500).json({ message: "Failed to fetch appointment details due to a server error." });
    }
};



exports.updateAppointment = async (req, res) => {
    const { appointmentId } = req.params;
    const {
        doctorName,
        appointmentDate,
        description,
        patientName,
        patientAge,
        patientGender,
        patientPhone
    } = req.body;

    if (!appointmentId || !doctorName || !appointmentDate || !patientName || !patientAge || !patientGender || !patientPhone) {
        return res.status(400).json({ message: "Missing required fields for update." });
    }

    try {
    
        const formattedDate = new Date(appointmentDate).toISOString().slice(0, 19).replace('T', ' ');

        const [result] = await db.query(
            `UPDATE Appointments SET
                doctorName = ?,
                appointmentDate = ?,
                description = ?,
                patientName = ?,
                patientAge = ?,
                patientGender = ?,
                patientPhone = ?
             WHERE id = ?`,
            [doctorName, formattedDate, description || null, patientName, patientAge, patientGender, patientPhone, appointmentId]
        );

        if (result.affectedRows === 0) {
             return res.status(404).json({ message: "Appointment not found or no changes made." });
        }

        res.status(200).json({ message: "Appointment updated successfully." });
    } catch (error) {
        console.error("Update Error:", error);
        res.status(500).json({ message: "Failed to update appointment due to a server error." });
    }
};

exports.deleteAppointment = async (req, res) => {
    const { appointmentId } = req.params;

    if (!appointmentId) {
        return res.status(400).json({ message: "Appointment ID is required." });
    }

    try {
     
        const [result] = await db.query(
            "DELETE FROM Appointments WHERE id = ?",
            [appointmentId]
        );

        if (result.affectedRows === 0) {
          
            return res.status(404).json({ message: "Appointment not found." });
        }

        res.status(200).json({ message: "Appointment deleted successfully." }); // Or use 204 No Content
    } catch (error) {
        console.error("Delete Error:", error);
        res.status(500).json({ message: "Failed to delete appointment due to a server error." });
    }
};

