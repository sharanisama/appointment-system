var mysql = require('mysql2');

// Create a connection with promise support
const db = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: '124578',  // Replace with your actual MySQL password
    database: 'appointment_db'  // Database name
});

// Using promise wrapper
const promiseDb = db.promise();

promiseDb.connect(err => {
    if (err) {
        console.error('Error connecting to the database: ' + err.message);
        return;
    }
    console.log('Connected to the database');
});

module.exports = promiseDb;  // Export the promise-based connection
