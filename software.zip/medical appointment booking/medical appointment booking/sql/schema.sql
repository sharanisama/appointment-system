-- Users Table
CREATE TABLE Users (
    id INT PRIMARY KEY AUTO_INCREMENT,
    username VARCHAR(100) NOT NULL,
    email VARCHAR(100) NOT NULL UNIQUE,
    password VARCHAR(100) NOT NULL
);

-- Appointments Table (with patient details)
CREATE TABLE Appointments (
    id INT PRIMARY KEY AUTO_INCREMENT,
    userId INT,
    doctorName VARCHAR(100),
    appointmentDate DATETIME,
    description TEXT,
    patientName VARCHAR(255),
    patientAge INT,
    patientGender VARCHAR(10),
    patientPhone VARCHAR(20),
    FOREIGN KEY (userId) REFERENCES Users(id)
);
